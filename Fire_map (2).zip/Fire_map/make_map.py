import streamlit as st
import folium 
import pandas as pd 
import matplotlib.pyplot as plt
import numpy as np
from streamlit_folium import st_folium


df = pd.read_excel('/Users/Chris/Desktop/Python_lessons/Fire_map/fires_coor.xlsx')

lon = list(df.loc[:, 'X-ENGAGE'].to_numpy())
lat = list(df.loc[:, 'Y-ENGAGE'].to_numpy())
weight = list(df.loc[:, 'intensity'].to_numpy())


for i in range(len(weight)):
  if np.isnan(weight[i]):
    weight[i] = 0.0
    

data = {'lat': lat, 'lon': lon, 'weight': weight}
data_list = [(i,j,k) for i,j,k in zip(lat,lon,weight)]

m = folium.Map(location=[lon[1], lat[1]], zoom_start=7.5, width=1300, height=100)

q0 = np.quantile(weight, 0.10)
q1 = np.quantile(weight, 0.25)
q2 = np.quantile(weight, 0.50)
q3 = np.quantile(weight, 0.75)
q4 = np.quantile(weight, 0.90)

for i, j, w in data_list:
    color = '#2E68E6'  # blue color
    if w > q0:
        color = '#EFEA79'  # yellow color
    if w > q1:
        color = '#DC791C'
    if w > q3:
        color = '#F74D4D'
    if w > q4:
        color = '#400101'  # red color

    folium.Circle(
        location=(j, i),
        radius=700,
        fill=True,
        color=color,
        fill_color=color
    ).add_to(m)

st.write("# Πυρκαγιές Αττικής")
st.write('### Σύνοψη')
st.write('''Πραγματοποιήθηκε έρευνα για τις εκτάσεις
που έχουν καεί στην περιοχή της Αττικής, μέσα απο τα ανοιχτά
δεδομένα που υπάρχουν στον ιστότοπο του πυροσβεστικού σώματος Ελλάδος.
Τα αρχεία αυτά περιλαμβάνουν κατηγορίες συνόλων δεδομένων που διατίθενται και σε ανοιχτό μηχαναγνώσιμο μορφότυπο. 
Θα αναλυθούν τα δεδομένα που αφορούν τα δασικά συμβάντα, στα οποία επεμβαίνει το Πυροσβεστικό Σώμα. 
Ο υπερσύνδεσμος, που περιλαμβάνει τα σχετικά αρχεία τύπου (xls), που σε αυτά θα γίνει scraping είναι ο ακόλουθος: \n
https://www.fireservice.gr/el/synola-dedomenon''')

st.write('### Έμπνευση')
st.write('''Η έμπνευση προέρχεται απο τις εμπειρίες των μελών της ομάδας, τις οποίες αποκόμισαν απο τις φωτιές στην περιοχή των Θρακομακεδόνων το καλοκαίρι του 2022.
Θα προσπαθήσουμε να δημιουργήσουμε έναν αντίστοιχο χάρτη, με αυτόν του υπερσυνδέσμου του Υπουργείου Πολιτικής Προστασίας, που θα απεικονίζει την συχνότητα των περιοχών που έχουν καεί και όχι τον κίνδυνο φωτιάς: https://www.civilprotection.gr/el/%CE%B7%CE%BC%CE%B5%CF%81%CE%AE%CF%83%CE%B9%CE%BF%CF%82-%CF%87%CE%AC%CF%81%CF%84%CE%B7%CF%82-%CF%80%CF%81%CF%8C%CE%B2%CE%BB%CE%B5%CF%88%CE%B7%CF%82-%CE%BA%CE%B9%CE%BD%CE%B4%CF%8D%CE%BD%CE%BF%CF%85-%CF%80%CF%85%CF%81%CE%BA%CE%B1%CE%B3%CE%B9%CE%AC%CF%82-01082008 Διαφορετικά θα θέλαμε να κάνουμε κάτι πιο σύνθετο όπως land.copernicus: https://land.copernicus.eu/pan-european/corine-land-cover/clc-2006/#''')

st.write('### Ερευνητικά ερωτήματα')

st.write('##### 1)') 
st.write('- Συχνότητα που καιγονται περιοχές (πόσες φορές έχουν καεί συγκεκριμένες περιοχές)')
st.write('- Σύνολο καμμένων εκτάσεων')


fire_counts = pd.read_excel('/Users/Chris/Desktop/Python_lessons/Fire_map/fire_counts.xlsx')



fire_counts.columns = ['Περιοχή', 'Συχνότητα']
st.write('Χρησιμοποιώντας τα δεδομένα που εξαχθήκαν από τις παραπάνω πηγές, \
 παρουσιάζονται οι περιοχές και ο αριθμός των φορών που έχουν καεί κατά την διάρκεια 2000-2021.')
st.write(fire_counts)


st.write('##### 3) Πόσες δασικές και πόσες γεωργικές εκτάσεις')


ektaseis = pd.read_excel('/Users/Chris/Desktop/Python_lessons/Fire_map/ektaseis.xlsx')



ektaseis = ektaseis.iloc[:,1::]
st.write('Παρακάτω παρουσιάζεται ο πίνακας με τις δασικές και τις γεωργικές εκτάσεις που έχουν καεί κατά την διάρκεια 2000-2021.')
st.write('Όπου το άθροισμα της στήλης των γεωργικών εκτάσεων είναι {} και το άθροισμα της \
    στήλης των δασικών εκτάσεων είναι {}'.format(round(ektaseis.sum()[0]), round(ektaseis.sum()[1])))

st.write(ektaseis)


st.write('##### 4) Χρόνος κατάσβεσης')
st.write('Στον παρακάτω πίνακα παρουσιάζονται οι ημερομηνίες καθώς και οι ώρες έναρξης και κατάσβεσης της φωτιάς. Χρησιμοποιώντνας αυτές τις στήλες\
    έγινε υπολογισμός του χρόνου κατάσβεσης της φωτιάς για κάθε συμβάν.')

    

fire_time = pd.read_excel('/Users/Chris/Desktop/Python_lessons/Fire_map/fire_time.xlsx')


fire_time = fire_time.iloc[:, 1::]
st.write(fire_time)

st.write('#### Κατασκευή Χάρτη')
st.write('Χρησιμοποιώντας την βιβλιοθήκη folium της python δημιουργήθηκε ένας χάρτης. \
    Στον χάρτη απεικονίζονται οι καμένες περιοχές στις οποίες κωδικοποιήθηκε η συχνότητα πυρκαγιών\
        με την εξής λογική :  ')
st.write('Στο εύρος 1 εως 142 εάν ο αριθμός των φορών που έχει καεί μία περιοχή είναι μικρότερος του 10ου ποσοστιμορίου του τότε \
    η περιοχή λαμβάνει το χρώμα μπλέ. \
        \nΆν είναι μεταξύ του 10ου και του 25 ποσοστιμορίου, τότε λαμβάνει το χρώμα κίτρινο \
        \nΆν είναι μεταξύ του 25ου και του 75ου ποσοστιμορίου, τότε λαμβάνει το χρώμα πορτοκαλί\
        \nΆν είναι μεταξύ του 75οθ και του 90ου ποσοστιμορίου, τότε λαμβάνει το χρώμα κόκκινο \n \
        Αν είναι μεταξύ του 90ου και 100ου ποσοστιμορίου, τότε λαμβάνει το χρώμα σκούρο κόκκινο.')
st_folium(m)
